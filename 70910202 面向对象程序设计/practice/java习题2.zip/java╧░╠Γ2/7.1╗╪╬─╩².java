package p16250;

import java.util.Scanner;

public class P16250 {

	@SuppressWarnings("resource")
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		for(int i=a;i<=b;i++){
			if(String.valueOf(i).compareTo(ReverseStr(String.valueOf(i)))==0){
				System.out.println(i);
			}
		}
	}
	public static String ReverseStr(String str){
		String result="";
		for(int i=str.length()-1;i>=0;i--){
			result+=str.charAt(i);
		}
		return result;
	}

}

