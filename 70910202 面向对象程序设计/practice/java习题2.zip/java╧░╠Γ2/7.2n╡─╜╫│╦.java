package p15882;

import java.math.BigInteger;
import java.util.Scanner;

public class P15882 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		sc.close();
		BigInteger result=new BigInteger("1");
		while(n>0){
			BigInteger tempn=new BigInteger(String.valueOf(n));
			result=result.multiply(tempn);
			n--;
		}
		System.out.println(result);
	}

}

