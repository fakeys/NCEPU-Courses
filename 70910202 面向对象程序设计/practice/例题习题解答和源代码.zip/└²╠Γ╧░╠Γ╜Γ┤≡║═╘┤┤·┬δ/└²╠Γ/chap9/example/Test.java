package chap9.example;

public class Test {

	public static void go(){
	    go();
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		go();
	}

}
