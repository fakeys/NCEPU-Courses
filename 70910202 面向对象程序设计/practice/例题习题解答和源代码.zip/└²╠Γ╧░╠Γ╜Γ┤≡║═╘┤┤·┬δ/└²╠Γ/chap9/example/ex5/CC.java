package chap9.example.ex5;

import java.io.IOException;

public class CC {
	void doStuff() throws IOException {
		
	}
}
