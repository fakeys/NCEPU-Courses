package chap9.example.ex5;

public class CC3 extends CC{
//	void doStuff() throws Exception{		
//	}
}
