package chap9.example.ex5;

import java.io.FileNotFoundException;

public class CC2 extends CC{
	void doStuff() throws FileNotFoundException{		
	}
}
