package chap9.example.ex5;

public class CC5 extends CC{
	void doStuff(){		
	}
}
