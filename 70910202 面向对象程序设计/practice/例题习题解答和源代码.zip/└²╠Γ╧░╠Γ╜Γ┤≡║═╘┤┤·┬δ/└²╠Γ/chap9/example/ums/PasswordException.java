package chap9.example.ums;

public class PasswordException extends Exception{

	public PasswordException() {
		super();
	}
	
	public PasswordException(String msg) {
		super(msg);
	}
}
