package chap9.example.ums;

public class Pwd2ShortException extends Exception{

	public Pwd2ShortException() {		
	}
	public Pwd2ShortException(String msg) {
		super(msg);
	}

}
