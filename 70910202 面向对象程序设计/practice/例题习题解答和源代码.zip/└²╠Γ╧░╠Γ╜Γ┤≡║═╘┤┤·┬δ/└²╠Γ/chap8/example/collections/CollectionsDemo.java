package chap8.example.collections;

import java.util.*;
import java.util.Collections;

public class CollectionsDemo {
	public static void main(String[] args) {
		
		List list = Collections.synchronizedList(new ArrayList<String>());
		Set set = Collections.synchronizedSet(new HashSet<String>());
		Map map = Collections.synchronizedMap(new HashMap<String,String>());
	}

}
