package chap8.example.generic;

public class Student {

}
