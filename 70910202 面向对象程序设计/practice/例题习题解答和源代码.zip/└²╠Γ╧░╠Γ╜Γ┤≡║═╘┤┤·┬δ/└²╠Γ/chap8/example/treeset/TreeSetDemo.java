package chap8.example.treeset;

import java.util.*;

public class TreeSetDemo {
	public static void main(String[] args) {
		Set set = new TreeSet();
		set.add("Lucy");
		set.add("Hellen");
		set.add("Andrew ");	
		System.out.println(set);	//���[Andrew,Hellen, Jimmy]
	}


}
