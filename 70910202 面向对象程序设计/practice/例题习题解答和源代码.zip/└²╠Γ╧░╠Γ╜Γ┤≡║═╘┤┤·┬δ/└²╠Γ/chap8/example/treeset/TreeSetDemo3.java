package chap8.example.treeset;

import java.util.Iterator;
import java.util.Set;

import java.util.TreeSet;

public class TreeSetDemo3 {
	
	public static void main(String[] args) {
		Set set = new TreeSet(new ComparatorName());
//		Set set = new TreeSet(new ComparatorNameAge());

		set.add(new Student("Lucy",20));
		set.add(new Student("Hellen",21));	
		set.add(new Student("Andrew",19));
		set.add(new Student("Andrew",20));	
		set.add(new Student("Andrew",20));
		
		//�õ�������������е�Ԫ��
		Iterator it = set.iterator();
		while(it.hasNext()){
			Student stu = (Student)it.next();
			System.out.println(stu.getName()+","+stu.getAge());	
		}				
	}
}
