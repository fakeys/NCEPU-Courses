package chap8.example.treeset;

import java.util.Set;

import java.util.TreeSet;



public class TreeSetDemo1 {

	public static void main(String[] args) {
		Set set = new TreeSet();

		set.add(new Student("Lucy",20));
		set.add(new Student("Hellen",21));	//�׳��쳣
		set.add(new Student("Jimmy",19));
		
		System.out.println(set.toString());	
	}

}
