package chap8.example.map;

import java.util.*;

public class MapDemo {

	/**
	 * Map��ʾ
	 */
	public static void main(String[] args) {
		Map map = new HashMap();
		
		map.put("1", "song");
		map.put("2", "zhang");
		map.put("3", "andrew");
		
		Collection c = map.values();
		
		System.out.println(c);
		
		Set set = map.keySet();
		System.out.println(set);
		

	}

}
