package chap8.example.set;

import java.util.*;

public class HashSetDemo {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Set set = new HashSet();
		
		set.add(new Student("Lucy",20));
		set.add(new Student("Hellen",19));
		set.add(new Student("Andrew",21));
		set.add(new Student("Andrew",19));	//û����֮��ȫ��ͬ�Ķ��󣬴洢
		set.add(new Student("Andrew",21));	//�ö����Ѵ��ڣ�������

		
		for(Object obj: set){
			Student stu = (Student)obj;
			System.out.println(stu.getName()+","+stu.getAge());
		}
	}

}
