package chap8.example.set;

public class Student {
	private String name;
	private int age;
	
	public boolean equals(Object obj){
		if(obj==null)	return false;
		if(this==obj)	return true;
		
		if(obj instanceof Student){
			Student stu = (Student)obj;
			
			//������ȵ�������id��name����ͬ
			return this.name.equals(stu.name) && this.age==stu.age;
		}
		
		return false;
	}
	
	public int hashCode(){
		return  name.hashCode()^age^0x5f2ab673;   //ɢ�з���:ԭʼɢ���������ֵ�������
	}

	public Student() {
		
	}
	public Student(String name, int age) {
		super();
		this.name = name;
		this.age = age;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}	
}
