package chap5.example.ex7.v1;

public class StudentCloneError {
	private String name;
	private int age;
	
	public StudentCloneError() {
	}
	
	public StudentCloneError(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String toString(){
		return name+","+age;
	}	
}
