package chap5.example.ex7.v1;

public class Test {
	public static void main(String[] args){
		StudentCloneError stu1 = new StudentCloneError("Lucy",15);
		StudentCloneError stu2 = null;
//		try {
//			//�˾䱨��(the method clone() from the type Object is not visible) 
//			stu2 = (StudentCloneError)stu1.clone();
//		} catch (CloneNotSupportedException e) {
//			e.printStackTrace();
//		}
		System.out.println(stu1);
		System.out.println(stu2);	
	}
}
