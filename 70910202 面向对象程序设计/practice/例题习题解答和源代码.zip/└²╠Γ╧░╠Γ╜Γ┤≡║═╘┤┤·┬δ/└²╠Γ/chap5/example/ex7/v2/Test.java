package chap5.example.ex7.v2;

public class Test {
	public static void main(String[] args){
		Student stu1 = new Student("Lucy",15);
		Student stu2 = stu1.clone();
		System.out.println(stu1);
		System.out.println(stu2);
		stu1.setName("Hellen");
		System.out.println(stu1);
		System.out.println(stu2);
	}
}
