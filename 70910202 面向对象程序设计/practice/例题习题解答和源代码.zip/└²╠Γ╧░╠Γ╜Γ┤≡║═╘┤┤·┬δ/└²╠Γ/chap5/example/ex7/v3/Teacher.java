package chap5.example.ex7.v3;

public class Teacher implements Cloneable{
	private String name;
	
	public Teacher(String name) {
		this.name = name;
	}
	public Teacher() {
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Teacher clone(){//��дclone����
		Teacher tea = null;
		try {
			tea = (Teacher)super.clone();
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return tea;
	}
}
