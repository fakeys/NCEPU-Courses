package chap5.example.ex7.v3;

public class Test {
	public static void main(String[] args){
		Teacher teacher = new Teacher("Grace");
		Student stu1 = new Student("Lucy",15, teacher);
		Student stu2 = stu1.clone();

		stu1.getTeacher().setName("Kenzo");
		System.out.println("stu1:"+stu1);
		System.out.println("stu2:"+stu2);
	}
}
