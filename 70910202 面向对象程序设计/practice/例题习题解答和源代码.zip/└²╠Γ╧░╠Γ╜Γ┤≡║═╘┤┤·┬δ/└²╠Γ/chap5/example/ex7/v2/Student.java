package chap5.example.ex7.v2;

public class Student implements Cloneable{
	private String name;
	private int age;
	
	public Student() {
	}
	public Student(String name, int age) {
		this.name = name;
		this.age = age;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Student clone(){ //��дObject���clone()����
		Student stu = null;
		try {
			stu = (Student)super.clone();  //����Object���clone()������ɸ���		
		} catch (CloneNotSupportedException e) {
			e.printStackTrace();
		}
		return stu;
	}
	
	public String toString(){
		return name+","+age;
	}
	
}
