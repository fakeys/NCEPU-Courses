package chap5.example.ex4;

public class Animal {
	public int a;
	public void move(){
		System.out.println("�ҿ���move...");
	}
}


