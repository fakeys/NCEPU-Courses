package chap5.example.finaldemo;

public final class FinalClass {

}
//class Foo extends FinalClass{
//
//}
