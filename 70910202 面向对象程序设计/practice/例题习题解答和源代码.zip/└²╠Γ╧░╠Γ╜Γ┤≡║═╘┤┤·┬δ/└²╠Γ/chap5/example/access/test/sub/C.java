package chap5.example.access.test.sub;

public class C {
	public int a;
	protected int b;
	int c;
	private int d;
	
	public int getD(){
		return d;
	}
}
