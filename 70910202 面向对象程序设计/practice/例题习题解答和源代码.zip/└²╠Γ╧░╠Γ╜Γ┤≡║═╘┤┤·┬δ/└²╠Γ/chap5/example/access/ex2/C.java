package chap5.example.access.ex2;

public class C {
	public int a=1;
	protected int b=2;
	int c=3;
	private int d=4;
	
	public int getD(){
		return d;
	}
	protected void t(){}
}
