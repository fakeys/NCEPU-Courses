package chap5.example.access.ex2.test;


public class AccessTest extends C{

}
