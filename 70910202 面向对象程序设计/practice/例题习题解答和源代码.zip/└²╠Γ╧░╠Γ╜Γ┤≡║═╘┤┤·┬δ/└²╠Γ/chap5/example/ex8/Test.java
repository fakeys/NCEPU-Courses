package chap5.example.ex8;

public class Test {
	
	public static void main(String[] args) {
//		new Circle();
		new Circle("��Բ",100);

	}

}
