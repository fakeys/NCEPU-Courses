package chap6.example.ex2.ocp1;

public class LineChart {
	public void display(){
		
	}

}
