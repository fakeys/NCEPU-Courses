package chap6.example.ex2.ocp2;

public class PieChart extends AbstractChart{

	public void display() {
		System.out.println("display a pie chart...");		
	}	
}

