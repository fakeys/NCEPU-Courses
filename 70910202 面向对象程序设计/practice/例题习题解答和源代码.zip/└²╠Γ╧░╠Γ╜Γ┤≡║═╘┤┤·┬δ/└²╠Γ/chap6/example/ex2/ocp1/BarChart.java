package chap6.example.ex2.ocp1;

public class BarChart {
	public void display(){
		System.out.println("display a bar chart...");
	}
}
