package chap6.example.ex2.ocp2;

public class BarChart extends AbstractChart{
	public void display() {
		System.out.println("display a bar chart...");		
	}	

}
