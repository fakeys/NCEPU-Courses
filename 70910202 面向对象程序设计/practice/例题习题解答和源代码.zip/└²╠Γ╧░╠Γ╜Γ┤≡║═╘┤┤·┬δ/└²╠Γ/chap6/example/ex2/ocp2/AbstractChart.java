package chap6.example.ex2.ocp2;

public abstract class AbstractChart {
	public abstract void display();
}
