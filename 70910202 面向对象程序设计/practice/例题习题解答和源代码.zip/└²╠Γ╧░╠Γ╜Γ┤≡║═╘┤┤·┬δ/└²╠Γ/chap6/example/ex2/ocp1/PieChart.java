package chap6.example.ex2.ocp1;

public class PieChart {
	public void display(){
		System.out.println("display a pie chart...");
	}

}
