package chap6.example.ex5.v1;

public class MobileHardDisk{
	public void read() {
		System.out.println("Reading from MobileHardDisk����");
	}

	public void write() {
		System.out.println("Writing to MobileHardDisk");
	}

}
