package chap6.example.ex5.v1;

public class FlashDisk{
	public void read() {
		System.out.println("Reading from FlashDisk����");
	}
	public void write() {
		System.out.println("Writing to FlashDisk����");
	}
}
