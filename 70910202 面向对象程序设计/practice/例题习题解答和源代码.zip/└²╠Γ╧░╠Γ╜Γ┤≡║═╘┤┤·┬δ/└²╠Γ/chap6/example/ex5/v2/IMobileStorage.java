package chap6.example.ex5.v2;

public interface IMobileStorage {	
	void read();
	void write();
}
