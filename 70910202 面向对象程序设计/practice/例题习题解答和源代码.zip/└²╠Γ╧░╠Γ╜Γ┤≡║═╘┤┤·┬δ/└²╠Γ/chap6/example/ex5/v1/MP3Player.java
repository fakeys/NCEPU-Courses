package chap6.example.ex5.v1;

public class MP3Player{
	public void read() {
		System.out.println("Reading from MP3Player����");
	}

	public void write() {
		System.out.println("Writing to MP3Player����");
	}
	
	public void playMusic(){
		System.out.println("play music����");
	}
}
