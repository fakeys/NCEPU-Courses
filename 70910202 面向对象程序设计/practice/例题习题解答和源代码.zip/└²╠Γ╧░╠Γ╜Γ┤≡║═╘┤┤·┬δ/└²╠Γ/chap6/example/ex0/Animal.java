package chap6.example.ex0;

public class Animal {
	public void move(){
		System.out.println("�ҿ���move...");
	}
}
