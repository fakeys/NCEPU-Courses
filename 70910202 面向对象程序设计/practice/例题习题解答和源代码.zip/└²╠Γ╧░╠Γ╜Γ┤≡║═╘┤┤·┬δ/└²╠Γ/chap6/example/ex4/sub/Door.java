package chap6.example.ex4.sub;

public interface Door {
	public  void open();
	public  void close();
	public void alarm();
}
