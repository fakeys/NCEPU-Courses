package chap6.storage.impl;

import chap6.storage.IMobileStorage;

public class FlashDisk implements IMobileStorage {
	public void read() {
		System.out.println("Reading from FlashDisk����");
	}
	public void write() {
		System.out.println("Writing to FlashDisk����");
	}
}
