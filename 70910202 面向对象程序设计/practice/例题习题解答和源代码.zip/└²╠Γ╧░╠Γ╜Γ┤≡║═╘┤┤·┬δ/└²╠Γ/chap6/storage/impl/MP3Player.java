package chap6.storage.impl;

import chap6.storage.IMobileStorage;

public class MP3Player implements IMobileStorage {
	public void read() {
		System.out.println("Reading from MP3Player����");
	}

	public void write() {
		System.out.println("Writing to MP3Player����");
	}

}
