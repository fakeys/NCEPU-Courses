package chap6.storage.impl;

import chap6.storage.IMobileStorage;


public class MobileHardDisk implements IMobileStorage {
	public void read() {
		System.out.println("Reading from MobileHardDisk����");
	}
	public void write() {
		System.out.println("Writing to MobileHardDisk");
	}
}
