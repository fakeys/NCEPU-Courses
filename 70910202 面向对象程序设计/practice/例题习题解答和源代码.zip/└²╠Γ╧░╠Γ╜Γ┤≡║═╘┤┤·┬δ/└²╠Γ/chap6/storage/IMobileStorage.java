package chap6.storage;

public interface IMobileStorage {	
	void read();
	void write();
}
