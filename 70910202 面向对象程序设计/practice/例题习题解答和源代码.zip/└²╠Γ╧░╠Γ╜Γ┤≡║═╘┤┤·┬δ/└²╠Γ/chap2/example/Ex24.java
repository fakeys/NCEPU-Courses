package chap2.example;

public class Ex24 {

	/**
	 * λ����
	 */
	public static void main(String[] args) {
		System.out.println( 15&37 );
		System.out.println( 52|7 );
		System.out.println( 85^127 );	
		
		System.out.println( -105>>2);
		System.out.println( 11<<2 );
		
		System.out.println(Integer.toBinaryString(-123));
		System.out.println( -123>>>2 );
		
	}

}
