package chap2.example;

public class EX21 {

	/**
	 * 
	 */
//	public static void main(String[] args) {
//
//		double d = 5, e=5.123456;
//		int i = 5;
//		if(d==i){
//			System.out.println("=");
//		}

		
//		System.out.println(Byte.MAX_VALUE);
//		System.out.printf("%x\n",Byte.MAX_VALUE);
//		
//		System.out.println(Byte.MIN_VALUE);
//		System.out.printf("%x\n",Byte.MIN_VALUE);
//		
//		
//		System.out.println(Short.MAX_VALUE);
//		System.out.printf("%x\n",Short.MAX_VALUE);
//		
//		System.out.println(Short.MIN_VALUE);
//		//System.out.println(Integer.toBinaryString(Short.MIN_VALUE).substring(16));
//		System.out.printf("%x\n",Short.MIN_VALUE);
//
//		
//		System.out.println(Integer.MAX_VALUE);
//		System.out.printf("%x\n",Integer.MAX_VALUE);
//		
//		System.out.println(Integer.MIN_VALUE);
//		System.out.printf("%x\n",Integer.MIN_VALUE);
//		
//		System.out.println(Long.MAX_VALUE);
//		System.out.printf("%x\n",Long.MAX_VALUE);
//		
//		System.out.println(Long.MIN_VALUE);
//		System.out.printf("%x\n",Long.MIN_VALUE);
//		
//		System.out.println(Float.MAX_VALUE);
//			
//		System.out.println(Float.MIN_VALUE);
//
//		
//		System.out.println(Double.MAX_VALUE);
//		
//		System.out.println(Double.MIN_VALUE);
//	}
	
	public static void main(String[] args) {
		int a=10,b=20;
			
		System.out.println("a+b="+a+b);       //ͬ���ȼ�����������մ����ҵĴ������
		System.out.println("a+b="+(a+b));     //���Ÿı��˼�������ȼ�
	}


}
