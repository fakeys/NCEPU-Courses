package chap2.example;

public class Ex26 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//int i=(char)(byte)(-1);
		
		int i=(char)-1;
		
		System.out.println(Integer.toBinaryString(i)+","+i);
		
		int big = 123456789;
		double f=big;
		
		System.out.println(f);
		

		
	}

}
