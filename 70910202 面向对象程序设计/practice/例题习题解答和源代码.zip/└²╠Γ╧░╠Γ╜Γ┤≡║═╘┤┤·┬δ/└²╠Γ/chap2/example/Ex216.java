package chap2.example;

public class Ex216 {

	/**
	 * ���ֽ�����
	 */
	public static void main(String[] args) {
		printPyramid(7);
		printPyramid('g');
	}
	
	public static void printPyramid(int n){//��ӡn��������ɵĽ�����
		for(int i=1; i<=n; i++){
			for(int j=1; j<=n-i; j++){
				System.out.print("  ");
			}
			for(int j=1; j<=i; j++){
				System.out.print(j+" ");
			}
			for(int j=i-1; j>=1; j--){
				System.out.print(j+" ");
			}
			System.out.println();			
		}		
	}
	public static void printPyramid(char c){//��ӡn���ַ���ɵĽ�����
		for(int i=1; i<=c-'a'+1; i++){
			for(int j=1; j<=c-'a'-i+1; j++){
				System.out.print("  ");
			}
			for(int j=0; j<i; j++){
				System.out.printf("%2c",(j+'a'));
			}
			for(int j=i-2; j>=0; j--){
				System.out.printf("%2c",(j+'a'));
			}
			System.out.println();			
		}		
	}

}
