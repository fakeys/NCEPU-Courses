package ums.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import ums.dao.UserDao;

public class DaoFactory {
	//���þ�̬����飬�ڹ����౻����ʱ��ִ�������ļ��Ķ�ȡ
	private static Properties props = new Properties();
	static {		
		try {
			props.load(new FileInputStream("dao.properties"));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	public static Object getDao(String name) {
		Object dao = null;
		String userDao = props.getProperty(name);
		try {
			dao = Class.forName(userDao).newInstance();
		} catch (InstantiationException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
		} 
		return dao;
	}
}
