package chap13.example.ex3;

public class Test {
	public static void main(String[] args){
		UserDao dao = new UserDao();
//		User user = new User("happydog3@126.com","happydog","����");
//		dao.insert(user);
		
//		dao.delete(1);
		
//		dao.update(2,user);
		
//		User u = dao.select(2);
//		System.out.println(u);
		
	}
}
