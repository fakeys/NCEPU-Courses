package chap13.example.ex4;

import java.text.SimpleDateFormat;
import java.util.Date;

public class User {
	private int id;
	private String email;
	private String username;
	private String hobbies;
	private Date lastLoginDate;
	
	
	public User() {
	}

	public User(String email, String username, String hobbies) {
		this.email = email;
		this.username = username;
		this.hobbies = hobbies;
	}
	
	public User(String email, String username, String hobbies,
			Date lastLoginDate) {
		super();
		this.email = email;
		this.username = username;
		this.hobbies = hobbies;
		this.lastLoginDate = lastLoginDate;
	}

	public User(int id, String email, String username, String hobbies) {
		this.id = id;
		this.email = email;
		this.username = username;
		this.hobbies = hobbies;
	}
	
	public User(int id, String email, String username, String hobbies,
			Date lastLoginDate) {
		super();
		this.id = id;
		this.email = email;
		this.username = username;
		this.hobbies = hobbies;
		this.lastLoginDate = lastLoginDate;
	}

	public Date getLastLoginDate() {
		return lastLoginDate;
	}

	public void setLastLoginDate(Date lastLoginDate) {
		this.lastLoginDate = lastLoginDate;
	}

	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getHobbies() {
		return hobbies;
	}
	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}
	public String toString(){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		StringBuilder sb = new StringBuilder();
		sb.append(id).append(",").append(email).append(",")
		.append(username).append(",").append(hobbies)
		.append(",").append(sdf.format(lastLoginDate));
		return sb.toString();
	}
	

}
