package chap13.example.ex2;

import java.sql.Connection;

import java.sql.SQLException;
import java.sql.Statement;

import chap13.util.ConnectionFactory;

public class UserDao {
	private Connection con;
	
	public UserDao() {
	}
	
	public void insert(){
		Statement st = null;
		try {
			con = ConnectionFactory.getConnection();
			//1.����Statement����
			st = con.createStatement();
			//2.����SQL��䣺����в���һ����¼
			String sql = "insert into user(email,username,hobbies) ";
			sql += "values('grace@126.com','grace','ѧϰ')";
			System.out.println(sql);
			//3.ִ��SQL���
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if(st!=null ) {try {st.close();} catch (SQLException e) {e.printStackTrace();}}
			if(con!=null ) {try {con.close();} catch (SQLException e) {e.printStackTrace();}}
		}
		
	}

	public void insert(User user){
		Statement st = null;
		try {			
			con = ConnectionFactory.getConnection();
			
			//1.����Statement����
			st = con.createStatement();
			//2.����SQL��䣺����в���һ����¼
			String sql = "insert into user(email,username,hobbies) ";
			sql += "values('"+user.getEmail()+"','"+user.getUsername()+"','"+user.getHobbies()+"')";
			System.out.println(sql);
			//3.ִ��SQL���
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		} finally{
			if(st!=null ) {try {st.close();} catch (SQLException e) {e.printStackTrace();}}
			if(con!=null ) {try {con.close();} catch (SQLException e) {e.printStackTrace();}}
		}
	}
	
	public void delete(){	
		Statement st = null;
		try {
			con = ConnectionFactory.getConnection();
			//1.����Statement����
			st = con.createStatement();
			//2.����SQL��䣺ɾ����¼
			String sql = "delete from user where id=1";
			System.out.println(sql);
			//3.ִ��SQL���
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if(st!=null ) {try {st.close();} catch (SQLException e) {e.printStackTrace();}}
			if(con!=null ) {try {con.close();} catch (SQLException e) {e.printStackTrace();}}
		}
	}
	
	public void update(){
		Statement st = null;
		try {
			con = ConnectionFactory.getConnection();
			//1.����Statement����
			st = con.createStatement();
			//2.����SQL��䣺�޸ļ�¼
			String sql = "update user set username='happyrabbit'";
			sql +=  "where username='happydog'";
			System.out.println(sql);
			//3.ִ��SQL���
			st.executeUpdate(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			if(st!=null ) {try {st.close();} catch (SQLException e) {e.printStackTrace();}}
			if(con!=null ) {try {con.close();} catch (SQLException e) {e.printStackTrace();}}
		}
		
	}

}
