package chap13.example.ex2;

public class Test {
	public static void main(String[] args){
		UserDao dao = new UserDao();
//		User user = new User("happydog@126.com","happydog","����");
//		dao.addUser(user);
		dao.insert();
		
		dao.delete();
		
		dao.update();
		
	}
}
