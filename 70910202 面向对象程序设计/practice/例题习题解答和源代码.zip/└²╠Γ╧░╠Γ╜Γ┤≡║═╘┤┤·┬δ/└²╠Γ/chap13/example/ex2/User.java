package chap13.example.ex2;

public class User {
	private int id;
	private String email;
	private String username;
	private String hobbies;
	
	
	public User() {
	}

	public User(String email, String username, String hobbies) {
		this.email = email;
		this.username = username;
		this.hobbies = hobbies;
	}
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getHobbies() {
		return hobbies;
	}
	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}
	
	

}
