package chap4.example.testimport.sub;

class SubPackageClass {

}
