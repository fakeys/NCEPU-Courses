package chap4.example;

public class StaticTest {
	public static void sayHello(){
		System.out.println("Hello world!");
	}
	
	public static void main(String[] args) {
		sayHello();
	}
}
