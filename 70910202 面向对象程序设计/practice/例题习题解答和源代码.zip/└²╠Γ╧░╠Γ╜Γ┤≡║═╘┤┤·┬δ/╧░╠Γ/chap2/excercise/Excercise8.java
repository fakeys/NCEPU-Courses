package chap2.excercise;

import java.util.Scanner;

public class Excercise8 {

	/**
	 * ��������������Ƽ�
	 */
	public static void main(String[] args) {		
		System.out.print("input distance:");
		Scanner scn = new Scanner(System.in);
		int distance = scn.nextInt();		
		
		int price;
		if(distance<=6&& distance>0){
			price=3;
		}else if(distance<=12){
			price=4;
		}else if(distance<=22){
			price=5;
		}else if(distance<=32){
			price=6;
		}else {
			if((distance-32)%20!=0){
				price = 6+ (distance-32)/20+1;
			}else{
				price = 6+ (distance-32)/20;
			}		
		}
		
		System.out.printf("price=%d\n",price);
	}
}
