package chap2.excercise;

public class Excercise3 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//�����ַ��������
		System.out.println(0=='0');
		System.out.println(0=='\u0000');
		System.out.println('0'=='\u0000');
		System.out.println('8'=='5'+'3');
		System.out.println('8'=='5'+3);
		System.out.println(8=='5'+'3');
		System.out.println(8=='5'+3);
		
		
	}
	
//	false
//	true
//	false
//	false
//	true
//	false
//	false

}
