package chap2.excercise;

public class Excercise12 {

	/**
	 * ��������
	 */
	public static void main(String[] args) {
		int x,count;
		
		count=0;
		for(x=2; x<=1000; x++){
			if(isSuperPrime(x)){
				System.out.printf("%4d",x);
				count++;
				if(count%5==0){
					System.out.println();
				}
			}				
		}
		System.out.printf("\n1000����%d����������\n\n",count);

	}
	
	static boolean isPrime(int  x){		
		for  (int div=2; div<=Math.sqrt(x); div++)
			if  (x%div==0)
				return false;
		return true;      
	}
	
	static boolean isSuperPrime(int x){
		while(x!=0){
			if(isPrime(x)&&isPrime(x/10)){
				x=x/10;
			}else{
				return false;
			}
		}
		return true;
	}

}
