package chap2.excercise;

import java.util.Scanner;

public class Excercise11 {

	/**
	 * ÿ��������������Ωһ�ر��ֽ�Ϊ���ɸ������ĳ˻�
	 */
	public static void main(String[] args) {
		int  num, div;
	    
		System.out.printf("����һ������:");
		Scanner scn = new Scanner(System.in);
	    num = scn.nextInt();
	    
	    while(isPrime(num)){
	    	System.out.printf("input again:");
	        num = scn.nextInt();
	    }
	    System.out.printf("%d=", num);
	    
	    div = 2;
	    while (num != 1)
	       if (num % div == 0){
	    	   System.out.printf("%d", div);
	             num = num / div;
	             if (num != 1){
	            	 System.out.printf("*");
	             }
	             div = 2;
	        }
	        else{
	             div = nextPrime(div);
	        }
	    	System.out.printf("\n");
	}

	static boolean isPrime(int  x){		
		for  (int div=2; div<=Math.sqrt(x); div++)
			if  (x%div==0)
				return false;
		return true;      
	}

	static int nextPrime(int x)	{
	    x++;
	    while (isPrime(x) == false)
	        x++;
	    return x;
	}
}
