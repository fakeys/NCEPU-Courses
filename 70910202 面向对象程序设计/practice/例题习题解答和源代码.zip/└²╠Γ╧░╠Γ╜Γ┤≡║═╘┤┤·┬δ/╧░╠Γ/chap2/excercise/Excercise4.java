package chap2.excercise;

public class Excercise4 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Long x=42L;
		Long y=44L;
		System.out.println(""+7+2+"");
		System.out.println(foo()+x+5+"");
		System.out.println(x+y+foo());

	}
	static String foo(){
		return "foo";
	}
	
//	72
//	foo425
//	86foo

}
