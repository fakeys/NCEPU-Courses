package chap9.excercise.ex3;

public class Test {

	public static void main(String[] args) {
//		try{
//			int x = Integer.parseInt("two");
//		}

	}

}
