package chap10.excercise.ex3;

import java.awt.BorderLayout;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JTextArea;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;

public class DocumentEventTest{
	private JFrame frame;
	private JButton save;
	private JTextArea area;
	
	public DocumentEventTest(){
		frame = new JFrame("document�¼�Test");
		save=new JButton("����");
		area=new JTextArea(5,30);		
	}
	
	public void addEventHandler(){
		save.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e){
				save.setEnabled(false);
			}
		});
		
		Document doc=area.getDocument();
		doc.addDocumentListener(new DocumentListener(){
			public void changedUpdate(DocumentEvent arg0) {
				save.setEnabled(true);
			}
			public void insertUpdate(DocumentEvent arg0) {
				save.setEnabled(true);
			}
			public void removeUpdate(DocumentEvent arg0) {
				save.setEnabled(true);
			}
		});
	}
	
	public void showMe(){
		frame.add(save,BorderLayout.NORTH);
		frame.add(area,BorderLayout.CENTER);
		
		addEventHandler();
		
		frame.pack();
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}

	public static void main(String[] args) {
		new DocumentEventTest().showMe();
	}

}
