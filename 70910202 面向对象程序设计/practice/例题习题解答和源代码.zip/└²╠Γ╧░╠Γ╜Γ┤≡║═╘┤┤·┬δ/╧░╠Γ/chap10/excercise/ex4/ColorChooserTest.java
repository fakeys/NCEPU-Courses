package chap10.excercise.ex4;

import java.awt.BorderLayout;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JColorChooser;
import javax.swing.JFrame;
import javax.swing.JPanel;

public class ColorChooserTest {
	private JFrame frame;
	private JButton button;
	
	public ColorChooserTest(){
		frame = new JFrame("ColorChooserTest");	
		button = new JButton("���ô�����ɫ");	
	}
	
	private void init(){				
		JPanel panel = new JPanel();
		panel.add(button);
		frame.add(BorderLayout.NORTH,panel);
	}
	
	public void showMe(){
		init();
		
		addEventHandler();

		frame.setBounds(200,200,300,200);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);		
	}
	
	public void addEventHandler(){  //�¼�������
		button.addActionListener(new ButtonHandler());
	}
	
	private class ButtonHandler implements ActionListener{
		public void actionPerformed(ActionEvent e) { 
			Color c =JColorChooser.showDialog(frame,"��ѡ��������ɫ",Color.BLACK);   //��̬����
			frame.getContentPane().setBackground(c);   //�Ȼ�ȡ���ڵ��ĵ����������ñ���ɫ
		}
	}
	public static void main(String[] args){
		new ColorChooserTest().showMe();
	}	
}
