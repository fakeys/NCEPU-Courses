package chap10.excercise.ex1;

import java.awt.BorderLayout;
import java.awt.event.FocusAdapter;
import java.awt.event.FocusEvent;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FocusEventTest extends JFrame{
	private JLabel label1,label2,label3,label4;
	private JTextField field1,field2;
	
	public FocusEventTest(){		
	}
	
	private void init(){
		JPanel pNorth = new JPanel();
		label1=new JLabel("�û���:");		
		field1=new JTextField(20);
		label3=new JLabel("     ");
		pNorth.add(label1);
		pNorth.add(field1);
		pNorth.add(label3);
		
		JPanel pSouth = new JPanel();		
		label2=new JLabel("email:");
		field2=new JTextField(20);
		label4=new JLabel("     ");
		pSouth.add(label2);
		pSouth.add(field2);
		pSouth.add(label4);
		
		this.add(BorderLayout.NORTH,pNorth);
		this.add(BorderLayout.CENTER,pSouth);		
	}
	
	public void showMe(){
		init();
		addEventHandler();		
		this.setBounds(200,200,500,150);
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void addEventHandler(){
		field2.addFocusListener(new CheckEmailHandler());
		field1.addFocusListener(new CheckUserNameHandler());
	}
	
	private class CheckEmailHandler extends FocusAdapter{
		public void focusLost(FocusEvent e) {		
			String regex_email="[a-zA-Z0-9_+.-]+@([a-zA-Z0-9-]+\\.)+[a-zA-Z0-9]{2,4}";
			String str=field2.getText();
			if(!str.matches(regex_email)){
				label4.setText("email��ʽ����");				
			}else{
				label4.setText("");
			}
		}
		public void focusGained(FocusEvent e) {
			label4.setText("");
		}
	}
	
	private class CheckUserNameHandler extends FocusAdapter{
		public void focusLost(FocusEvent e) {		
			String regex_name="\\w{6,8}";
			String str=field1.getText();
			if(!str.matches(regex_name)){
				label3.setText("�û���ʽ����");
			}else{
				label3.setText("");
			}
		}
		public void focusGained(FocusEvent e) {
			label3.setText("");
		}
	}
	
	public static void main(String[] args){
		new FocusEventTest().showMe();
	}
}
