package chap8.excercise.ex6;

import java.util.*;
import java.util.Collections;

public class CollectionsDemo {
	public static void main(String[] args) {	    
	  	    
	    //�Զ������Ա���򡢲���
	    List<Student> stu = new ArrayList<Student>();
	    stu.add(new Student("004", 80));
	    stu.add(new Student("005", 95));
	    stu.add(new Student("001", 71));
	    stu.add(new Student("002", 63));
	    stu.add(new Student("003", 59));
	
	    //�Զ������� 
	    //Comparator�Ƚ���
	    Collections.sort(stu, new ByScore());
	    System.out.println("��������"+stu); 
	    int index = Collections.binarySearch(stu, new Student("001",71),new ByScore());
	    System.out.println(index);	//2	  
	  }
	}

	//���շ����Ƚ�������! �ıȽϹ���
	class ByScore implements Comparator<Student>{
	  public int compare(Student obj1, Student obj2) {
		  if(obj1 instanceof Student && obj2 instanceof Student){
			  Student b1 = (Student)obj1;
			  Student b2 = (Student)obj2;
			  return b1.getScore()-b2.getScore();
		  }
		  return 0;
	  }
	}	
