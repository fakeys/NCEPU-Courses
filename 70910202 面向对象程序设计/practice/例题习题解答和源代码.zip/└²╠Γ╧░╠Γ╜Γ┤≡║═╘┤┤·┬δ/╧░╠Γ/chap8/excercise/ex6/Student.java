package chap8.excercise.ex6;

public class Student{
	private String id;
	private int score;	
	
	public String toString() {
		return id+":"+score;
	}

	public Student() {		
	}

		
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Student(String id, int score) {
		super();
		this.id = id;
		this.score = score;
	}

	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	
}
