package chap8.excercise.ex5;

public class ShopDemo {
	public static void main(String[] args) {
		Shop<Book> bookShop = new Shop<Book>(new Book("Java ���ļ���"));
		Book book = bookShop.buy();
		System.out.println(book);//Java ���ļ���
	  
		Shop<Food> foodShop = new Shop<Food>(new Food("�ɿ���"));
		Food food = foodShop.buy();
		System.out.println(food);//�ɿ���
	  
		Shop<Object> superMarket=new Shop<Object>(new Object());	  
  }
}
class Shop<P>{ //�̵�,<P>�Ƿ���, �̵�������Ʒ������
	private P product;
	public Shop(P p){
		product = p;
	}
	public P buy(){
		return product;
	}
}
class Food{
	private String name;
	public Food(String name){
		this.name = name;
	}
	public String toString() {
		return name;
	}
}
class Book{//��
	private String name;
	public Book(String name) {
		this.name = name;
	}
	public String toString() {
		return name;
	}
}