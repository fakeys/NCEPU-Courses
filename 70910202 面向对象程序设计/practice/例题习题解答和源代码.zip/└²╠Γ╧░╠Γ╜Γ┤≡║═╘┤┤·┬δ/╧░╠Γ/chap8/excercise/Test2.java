package chap8.excercise;

import java.util.HashMap;
import java.util.Map;

public class Test2 {
	public static void main(String[] args){
		Map<ToDos, String> m = new HashMap<ToDos, String>();
		ToDos t1 = new ToDos("Monday");
		ToDos t2 = new ToDos("Monday");
		ToDos t3 = new ToDos("Tuesday");
		m.put(t1,"working");
		m.put(t2,"cleaning");
		m.put(t3,"playing");
		System.out.println(m.size());
	}

}

class ToDos{
	String day;
	ToDos(String day){this.day=day;}
	public boolean equals(Object obj){
		return ((ToDos)obj).day==this.day;		
	}
	public int hashCode(){ return 999;}
}
