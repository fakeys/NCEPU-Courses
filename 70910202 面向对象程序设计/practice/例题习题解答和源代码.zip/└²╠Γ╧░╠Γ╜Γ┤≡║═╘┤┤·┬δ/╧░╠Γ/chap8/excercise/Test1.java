package chap8.excercise;

import java.util.*;

public class Test1 {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		
		

	}
	
	public static void before(){
		Set set = new TreeSet();
		set.add("2");
		set.add(3);
		set.add("1");
		Iterator it = set.iterator();
		while(it.hasNext()){
			System.out.print(it.next());
		}		
	}

}
