package chap8.excercise.ex3;

import java.util.Date;

public class Station {
	private String stopName;
	private Date time;
	private int residenceTime;
	
	public Station() {
	}
	public Station(String stopName, Date time, int residenceTime) {
		super();
		this.stopName = stopName;
		this.time = time;
		this.residenceTime = residenceTime;
	}
	public String getStopName() {
		return stopName;
	}

	public Date getTime() {
		return time;
	}
	public int getResidenceTime() {
		return residenceTime;
	}

}
