package chap8.excercise.ex3;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Trainschedule {
	private List<Station> list; 
	
	public Trainschedule() {
		list = new ArrayList<Station>();		
	}

	public void addStation() throws ParseException {
		Scanner scn = new Scanner(System.in);
		System.out.print("���복վ����:");
		int count = scn.nextInt();
		
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm");
		
		list = new ArrayList(count);
		for(int i=0; i<count; i++){
			System.out.print("�����"+(i+1)+"վ��:");
			String name = scn.next();
			System.out.print("�����"+(i+1)+"��վʱ��:");
			String time = scn.next();
			System.out.print("�����"+(i+1)+"ͣ��ʱ��:");
			int residenceTime = scn.nextInt();
			
			Station s = new Station(name, sdf.parse(time),residenceTime);
			list.add(s);
		}
	}
	
	public void showStations(){
		SimpleDateFormat sdf = new SimpleDateFormat("hh:mm");
		
		for(int i=0; i<list.size(); i++){
			Station s = list.get(i);
			System.out.println(s.getStopName()+"\t����ʱ��:"+sdf.format(s.getTime())+"\tͣ��"+s.getResidenceTime()+"����");
		}
	}
	public static void main(String[] args) throws ParseException{
		Trainschedule t = new Trainschedule();
		t.addStation();
		t.showStations();		
	}

}
