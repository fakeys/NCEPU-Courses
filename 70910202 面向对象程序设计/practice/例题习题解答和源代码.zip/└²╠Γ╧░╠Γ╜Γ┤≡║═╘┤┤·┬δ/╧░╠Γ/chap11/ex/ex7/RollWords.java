package chap11.ex.ex7;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

public class RollWords extends JFrame{	
	static RollWords.MyThread thread1, thread2;  //��Ա�ڲ���

	private void showMe(){ 
		setLayout(new GridLayout(4,1));
		setBackground(Color.LIGHT_GRAY);
		setBounds(200,140,400,240);
		setVisible(true);  //��ʾ����
	}
	
	private class MyThread extends Thread{ //�ڲ��߳���	
		//�߳���Ҫ�õ������
		private JLabel label;
		private JTextField text1,text2;
		private JButton start,interrupt;		
		private	int sleepTime;		
		
		public MyThread(String str){//��������
			super(str);
			
			//��ʼ���ַ��������ֺ�+���ɿո�
			text1 = new JTextField();
			for(int i=0; i<100; i++){
				str +=" ";
			}
			text1 = new JTextField(str);	
			
			sleepTime=(int)(Math.random()*100);
			label=new JLabel("sleep");
			text2 = new JTextField(""+sleepTime);
			start = new JButton("����");
			interrupt = new JButton("ֹͣ");
			
			init();		
			
			start.addActionListener(new MyListener());
			interrupt.addActionListener(new MyListener());	
		}
		
		private void init(){
			add(text1);
			JPanel panel;
			panel = new JPanel();
			panel.setLayout(new FlowLayout(FlowLayout.LEFT));
			panel.add(label);
			panel.add(text2);
			panel.add(start);
			panel.add(interrupt);
			add(panel);
			setVisible(true);  //��ʾ�߳��е����
		}		
		
		public void run(){ //�̷߳���
			String str;
			while(true){
				try{
					str = text1.getText();
					str = str.substring(1)+str.substring(0,1);  //�ַ�������
					text1.setText(str);
					Thread.sleep(sleepTime);
				}catch(InterruptedException e){//˯���ڼ䱻�жϣ���ť���������쳣
					break;
				}
			}
		}

		private class MyListener implements ActionListener{//�ڲ��࣬�����¼�������Ϊ�߳����еİ�ť����
			public void actionPerformed(ActionEvent e){
				if(e.getSource()==thread1.start || e.getSource()==thread1.interrupt)
					actionPerformed(e, thread1);
					
				if(e.getSource()==thread2.start || e.getSource()==thread2.interrupt)
					actionPerformed(e, thread2);
			}
			
			private void actionPerformed(ActionEvent e, MyThread thread){
				if(e.getSource()==thread.start){//����
					thread.sleepTime = Integer.parseInt(thread.text2.getText());
					thread.start();
					thread.start.setEnabled(false);
				}
				if(e.getSource()==thread.interrupt){//���
					thread.interrupt();
					thread.interrupt.setEnabled(false);
				}
			}
		}
	}
		
	public static void main(String[] args){
		RollWords w = new RollWords();
		w.showMe();
		
		thread1 = w.new MyThread("welcome!");
		thread2 = w.new MyThread("How are you!");
	}
}
