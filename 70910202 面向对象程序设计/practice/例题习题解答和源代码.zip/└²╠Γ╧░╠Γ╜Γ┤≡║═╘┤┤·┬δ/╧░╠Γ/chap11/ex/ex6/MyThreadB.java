package chap11.ex.ex6;

public class MyThreadB extends Thread{
	private MyStack stack;

	public MyThreadB(MyStack stack) {
		super();
		this.stack = stack;
	} 
	
	public void run(){
		System.out.println(Thread.currentThread().getName());
		stack.pop();
		stack.push("dingding");
		stack.push("dangdang");
		stack.pop();
		stack.print();
	}

}
