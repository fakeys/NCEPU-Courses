package chap11.ex.ex6;

public class MyStack{	
	private String[] data;
	private int size;
    private int top = 0;    
    
    public MyStack(int size) {
    	this.size = size;
		this.data= new String[size];
		this.top = 0;
	}

	public synchronized void push(String element){    
        //��while��ѭ���жϣ�������push����ʱ���±�Խ���쳣�������if��ֻ����һ��push����ʱ������
        while(top==size){
        	try{
        		this.wait();
        	}catch(Exception e){
        	}
        }
        data[top] = element;
        System.out.println(data[top]+ " pushed!");
        top++;
        this.notifyAll();
    }
    
    public synchronized String pop(){
        while(top==0){
        	try{
        		wait();
        	}catch(Exception e){
        	}
        }        
        top--;
        System.out.println(data[top]+" poped!");
        this.notifyAll();
        return data[top];
    }
    
    public synchronized void print(){
        for(int i=0; i<top; i++){
        	System.out.print(data[i]+" ");
        }
        System.out.println();
    }
    
	public static void main(String[] args){
		MyStack stack = new MyStack(10);
		
		MyThreadA t1 = new MyThreadA(stack);
		MyThreadB t2 = new MyThreadB(stack);
		
		t1.start();
		t2.start();		
	}
}
