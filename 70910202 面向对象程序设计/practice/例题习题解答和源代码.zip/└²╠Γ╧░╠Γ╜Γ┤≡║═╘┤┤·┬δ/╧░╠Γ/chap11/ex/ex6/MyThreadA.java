package chap11.ex.ex6;

public class MyThreadA extends Thread{
	private MyStack stack;

	public MyThreadA(MyStack stack) {
		super();
		this.stack = stack;
	} 
	
	public void run(){
		System.out.println(Thread.currentThread().getName());
		stack.push("haha");
		stack.push("xixi");
		stack.push("hehe");
		stack.pop();
		stack.print();
	}

}
