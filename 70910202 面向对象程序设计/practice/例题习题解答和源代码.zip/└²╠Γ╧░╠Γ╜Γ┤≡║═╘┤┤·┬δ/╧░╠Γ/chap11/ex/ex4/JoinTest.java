package chap11.ex.ex4;

public class JoinTest implements Runnable{

	public static void main(String[] args) {
		Thread t = new Thread(new JoinTest());
		t.start();
		System.out.print("m1 ");
		try {
			t.join();
		} catch (InterruptedException e) {
		}
		System.out.print("m2 ");
	}

	public void run() {
		System.out.print("r1 ");
		System.out.print("r2 ");
	}
}
