package chap11.ex.ex1;

public class StartRunTest implements Runnable{

	public static void main(String[] args) {		
//		new Thread(new StartRunTest()).start();
		new Thread(new StartRunTest()).run();
		System.out.println(Thread.currentThread().getName());		
	}
	
	public void run() {
		System.out.println(Thread.currentThread().getName());
	}
}
