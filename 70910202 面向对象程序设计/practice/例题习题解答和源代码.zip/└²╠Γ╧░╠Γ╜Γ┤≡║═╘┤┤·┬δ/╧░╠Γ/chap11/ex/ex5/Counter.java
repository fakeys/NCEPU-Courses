package chap11.ex.ex5;

public class Counter extends Thread{

	public static void main(String[] args) {		
		new Counter().start();
	}
	
	public void run() {
		for(int i=1; i<=100; i++){
			System.out.print(i+" ");
			if(i%10==0) {
				System.out.println("hello...");
			}
			try {
				Thread.sleep(10);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
	}
}
