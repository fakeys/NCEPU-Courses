package chap4.hotel2;

public class RegInfo {
	public static int NUMBER = 100;
	
	private Registration[] reg;
	private int count;
	
	public RegInfo() {
		reg= new Registration[NUMBER];
		count=0;
	}

	public boolean add(Registration r){
		if(count<NUMBER){
			reg[count++]=r;
			return true;
		}
		return false;
	}

	public Registration[] getReg() {
		return reg;
	}

	public int getCount() {
		return count;
	}
}
