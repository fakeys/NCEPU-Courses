package chap4.hotel2;

import java.util.Date;

public class Registration {
	private String roomId;
	private String customerName;
	private Date regDate;
	private boolean isExpired;

	public Registration() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Registration(String roomId, String customerName, Date regDate) {
		super();
		this.roomId = roomId;
		this.customerName = customerName;
		this.regDate = regDate;
	}
	
	public String getRoomId() {
		return roomId;
	}
	
	public String getCustomerName() {
		return customerName;
	}
	
	public Date getRegDate() {
		return regDate;
	}
	
	public boolean isExpired() {
		return isExpired;
	}
	
	public void setExpired(boolean isExpired) {
		this.isExpired = isExpired;
	}
}
