package chap4.hotel2;

public class Room{
	private String id;
	private boolean isEmpty;	
	
	public Room() {
		super();
		// TODO Auto-generated constructor stub
	}

	public void setStatus(boolean isEmpty){
		this.isEmpty=isEmpty;
	}
	
	public boolean getStatus(){
		return isEmpty;
	}
	
	public void setId(int floor, int number){
		id = floor + (number<=9? "0"+number : ""+number);
	}
	
	public String getId() {
		return id;
	}
}
