package chap4.hotel2;

public class RoomNo {
	private int floor;
	private int number;
	
	public RoomNo() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public RoomNo(int floor, int number) {
		super();
		this.floor = floor;
		this.number = number;
	}

	public int getFloor() {
		return floor;
	}

	public int getNumber() {
		return number;
	}

}
