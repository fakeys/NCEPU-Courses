package chap4.excercise.Ex67;

public class CircleTest {

	public static void main(String[] args) {
		Point p1 = new Point(1,1);		
		Point p2 = new Point(3);
		
		Circle c1 = new Circle(p1, 2);
		if(c1.contains(p2)){
			System.out.println("("+p2.getX()+","+p2.getY()+")��Բ("+p1.getX()+","+p1.getY()+"),r="+c1.getR()+"��");
		}else {
			System.out.println("("+p2.getX()+","+p2.getY()+")����Բ("+p1.getX()+","+p1.getY()+"),r="+c1.getR()+"��");
		}
	}
}
