package chap4.excercise.Ex67;

public class Circle {
	private Point center;  //Բ��
	private double r;  	//�뾶
	
	public Circle() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Circle(Point center) {
		this.center = center;
	}
	public Circle(Point center, double r) {
		this(center);
		this.r = r;
	}
	
	public double getArea(){
		return Math.PI * r *r;
	}
	
	/**
	 * �ж�ָ���ĵ��Ƿ���Բ��
	 * @param Point  
	 */
	public boolean contains(Point p){
		if(center.distance(p)<r){
			return true;
		}
		return false;
	}
	
	/**
	 * �ж�ָ���ĵ��Ƿ���Բ��
	 * @param int,int
	 */
	public boolean contains(int x, int y){
		if(center.distance(x, y)<r){
			return true;
		}
		return false;
	}
	public Point getCenter() {
		return center;
	}
	public void setCenter(Point center) {
		this.center = center;
	}
	public double getR() {
		return r;
	}
	public void setR(double r) {
		this.r = r;
	}	
	
}
