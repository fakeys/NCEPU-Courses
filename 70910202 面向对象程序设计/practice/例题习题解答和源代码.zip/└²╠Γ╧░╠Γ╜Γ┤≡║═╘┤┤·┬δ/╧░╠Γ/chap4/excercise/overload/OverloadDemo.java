package chap4.excercise.overload;

public class OverloadDemo {
	public static void main(String[] args) {
		Foo f = new Foo();
		
	    System.out.println(f.add(1, 1)); 
	    System.out.println(f.add('0', 1)); 
	    System.out.println(f.add(1L, 1)); 
	}
}
