package chap4.excercise.overload;

public class Foo {
	public int add(int a, int b){ 
		System.out.println("add(int,int)");
		return a+b;
	}
	
	public long add(long a, long b){
		System.out.println("add(long,long)");
		return a+b;
	}
	
//	public int add(char a, int b){
//		System.out.println("add(char,int)");
//		return a+b;
//	}
//	
//	public long add(long a, int b){
//		System.out.println("add(long,int)");
//		return a+b;
//	}
	
	public int add(int a, int b, int c){
		System.out.println("add(int,int,int)");
		return a+b+c;
	}
}