package chap7.excercise;

public class Ex2 {//P312

	public static void main(String[] args) {
		
	}

	public String makinStrings() {
		String s = "Fred";   
		s = s + "47";   
		s = s.substring(2, 5);  
		s = s.toUpperCase();   
		return s.toString();   
	}

}
