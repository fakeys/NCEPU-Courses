package chap7.excercise;

public class Ex4 {
	
	public static void main(String[] args){
		String str="123 abc+()Abc!@#cde<>CDEA";
		int times_number=0, times_lower=0, times_upper=0;
		
		System.out.println(str);
		
		//��ʼͳ�ƣ�ת��
		for(int i=0; i<str.length(); i++){
			char ch = str.charAt(i);
			if(Character.isDigit(ch)){
				times_number++;
			}else if(Character.isLowerCase(ch)){
				times_lower++;
			}else if(Character.isUpperCase(ch)){
				times_upper++;
			}
		}
		
		System.out.println("���֣�"+times_number);
		System.out.println("Сд��ĸ��"+times_lower);
		System.out.println("��д��ĸ��"+times_upper);		
	}

}
