package chap7.excercise;

public class Ex3 {
	
	public static void main(String[] args) {
		String path="e:\\myfile\\txt\\result.txt";   //ע��ת���ַ�
		
		int index = path.lastIndexOf("\\");   //�ҵ�����\\
		String fileName = path.substring(index+1);   //��ȡ�Ӵ�result.txt
		String newName = fileName.replaceAll(".txt",".java");  //�滻��չ��
		
		System.out.println(path);
		System.out.println(fileName); 
		System.out.println(newName);
	}

}
