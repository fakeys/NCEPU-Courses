package chap12.exercise.ex3;

import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;
import java.util.Scanner;

public class RandomAccessFileTest {	
	public static void main(String[] args) throws IOException{
		
		File demo = new File("demo");
		if(!demo.exists()){
			demo.mkdir(); //�����ļ���
		}
		File file = new File(demo, "data.dat");
		if(!file.exists()){
			file.createNewFile(); //�����ļ�
		}
		
		//��"rw"��ʽ����RandomAccessFile����
		RandomAccessFile raf = new RandomAccessFile(file,"rw");
		for(int i=0; i<10; i++){
			int number = (int)(Math.random()*100);
			System.out.println(number);
			raf.writeInt(number);
		}
		
		System.out.println("�������:");
		long fp = raf.getFilePointer();
		for(int i=9; i>=0; i--){
			raf.seek(i*4);
			int number = raf.readInt();
			System.out.println(number);
		}
	}
}

