package chap12.exercise.ex7;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Panel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;

import javax.swing.JButton;
import javax.swing.JFileChooser;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class FileWindows extends JFrame{
	private JTextArea area;
	private JFileChooser fileSave,fileLoad;
	private JButton buttonSave, buttonOpen;
	
	public FileWindows(){
		super("���ļ��Ի���Ĵ���");
		area = new JTextArea(20,60);
		area.setFont(new Font("Times New Roman",Font.BOLD,14));
		
		buttonOpen = new JButton("��");
		buttonSave = new JButton("����");
		fileSave = new JFileChooser();
		fileLoad = new JFileChooser();
		
	}
	
	public void showMe(){
		init();
		addEventHandler();
		this.pack();
		this.setVisible(true);
	}
	
	private void init(){
		Panel panelCenter = new Panel();
		JScrollPane pane = new JScrollPane(area);
		panelCenter.add(pane);	
		
		Panel panelSouth = new Panel();
		panelSouth.add(buttonOpen);
		panelSouth.add(buttonSave);
		
		this.add(panelCenter, BorderLayout.CENTER);
		this.add(panelSouth, BorderLayout.SOUTH);
	}
	
	private void addEventHandler(){
		//Ϊ�¼�Դע���¼�������
		buttonOpen.addActionListener(new openButtonActionHandler());
		buttonSave.addActionListener(new SaveButtonActionHandler());
	}
	
	private class  openButtonActionHandler implements ActionListener{	
		public void actionPerformed(ActionEvent e) {
			FileInputStream fis = null;
			InputStreamReader isr = null;
			BufferedReader br = null;
			StringBuilder text = new StringBuilder();
			
			try {
				String line; 
				fileLoad.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES );  
				fileLoad.showDialog(new JLabel(), "ѡ��");  
			    File file = fileLoad.getSelectedFile(); 
				
				fis = new FileInputStream(file);
				isr = new InputStreamReader(fis);
				br = new BufferedReader(isr);
				
				while((line=br.readLine())!=null) {
					text.append(line+"\n");
				}
				area.setText(text.toString());
			}catch(IOException ee){
				
			}
		}
	}

	private class SaveButtonActionHandler implements ActionListener{	
		public void actionPerformed(ActionEvent e) {
			String text = area.getText();
			FileOutputStream fos = null;
			PrintWriter pw = null;
			
			try {
				fileSave.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES );  
				fileSave.showDialog(new JLabel(), "ѡ��");  
			    File file = fileSave.getSelectedFile();  
			     			        
				fos = new FileOutputStream(file);
				pw = new PrintWriter(fos,true);
				
				pw.println(text+"\r\n");
			}catch(IOException ee){
				
			}
		}
	}
	
	public static void main(String[] args){
		new FileWindows().showMe();
	}

}
