package chap12.exercise.ex6;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;


public class SaveAddLineNumber {
	public static void main(String[] args) {
		FileInputStream fis = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		FileOutputStream fos = null;
		PrintWriter pw = null;

		try {
			String line; 
			fis = new FileInputStream("a.java");
			isr = new InputStreamReader(fis);
			br = new BufferedReader(isr);
			
			fos = new FileOutputStream("aabb.txt");
			pw = new PrintWriter(fos,true);
			int count=0;  //�к�
			while((line=br.readLine())!=null) {
				count++;
				pw.println("("+count+")"+line);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}  catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(pw!=null) pw.close();
			if(br!=null) try{br.close();} catch(Exception e){}
		}
	}

}
