package chap12.exercise.ex5;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;


public class PrintYangTriangle {
	public static void main(String[] args) {
		FileWriter fw = null;
		FileInputStream fis = null;
		InputStreamReader isr = null;
		BufferedReader br = null;
		
		int[][] tri = new int[20][];
		try {
			//�� ���������
			tri[0] = new int[1];
			tri[0][0]=1;
			for(int i=1; i<20; i++){
				tri[i] = new int[i+1];
				tri[i][0]=1;
				tri[i][i]=1;
				for(int j=1; j<i; j++){
					tri[i][j]=tri[i-1][j]+tri[i-1][j-1];
				}
			}
			
			//д���ļ�
			fw = new FileWriter("aa.txt");
			for(int i=0; i<20; i++){
				for(int j=0; j<=i; j++){
					fw.write(tri[i][j]+"\t");
				}
				fw.write("\r\n");  //ÿ�н��������һ���س�����
			}
			fw.flush();
			
			//����������
			String line; 
			fis = new FileInputStream("aa.txt");
			isr = new InputStreamReader(fis);
			br = new BufferedReader(isr);
			while((line=br.readLine())!=null) {
				System.out.println(line);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}  catch (IOException e) {
			e.printStackTrace();
		}finally{
			if(fw!=null)try {fw.close();} catch (IOException e) {e.printStackTrace();}
			if(br!=null) try{br.close();} catch(Exception e){}
		}
	}

}
