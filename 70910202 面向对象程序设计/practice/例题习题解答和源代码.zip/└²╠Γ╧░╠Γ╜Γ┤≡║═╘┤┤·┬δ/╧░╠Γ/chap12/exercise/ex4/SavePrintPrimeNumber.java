package chap12.exercise.ex4;

import java.io.DataInputStream;

import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class SavePrintPrimeNumber {
	
	public static void main(String[] args) {
//		int�͡�double�͡�long�͡�boolean�͡��ַ���		
		FileOutputStream fos = null;
		DataOutputStream dos = null;
		try{
			fos = new FileOutputStream("a.dat");
			dos = new DataOutputStream(fos);
			dos.writeInt(123456);
			dos.writeDouble(123.456);
			dos.writeLong(99998888);
			dos.writeBoolean(true);
			dos.writeUTF("³����Ư����");
			dos.writeUTF("����������");
		}catch(IOException e){
			e.printStackTrace();
		}finally{
			if(dos!=null) try{dos.close();} catch(Exception e){}
		}
		
		FileInputStream fis = null;
		DataInputStream dis = null;
		try{
			fis = new FileInputStream("a.dat");
			dis = new DataInputStream(fis);
			int i = dis.readInt();
			double d = dis.readDouble();
			long l = dis.readLong();
			boolean b = dis.readBoolean();
			String s1 = dis.readUTF();
			String s2 = dis.readUTF();
			System.out.println(i);
			System.out.println(d);
			System.out.println(l);
			System.out.println(b);
			System.out.println(s1);
			System.out.println(s2);
		}catch(IOException e){
			e.printStackTrace();
		}finally{
			if(dis!=null) try{dis.close();} catch(Exception e){}
		}
	}
}
