package chap5.excersice.ex4;

public class FinalStaticFieldDemo {
	public static void main(String[] args) {
		Foo f1 = new Foo();
		Foo f2 = new Foo();
	    System.out.println(f1.id+","+f2.id+","+Foo.index);//0,1,2
	    //f1.id = 4;//�����
	    Foo.index = 5;
	 } 
}

class Foo{
	static int index = 0;
	final int id;
	public Foo(){
		id = index++;
	}
}