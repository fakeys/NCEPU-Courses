package chap5.excersice.ex3;

public class Foo {	
	private final void test(){}
}

class Koo extends Foo{		
	private void test(){}	
}
