package chap13.excercise;
import java.sql.*;

import chap13.util.ConnectionFactory;
import chap13.util.ResourceUtil;
public class MetaDataDemo {
	public static void main(String[] args) {
		showTableStructure("role");
	}
	
	public static void showTableStructure(String tableName){
		Connection con = ConnectionFactory.getConnection();
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			String sql = "select * from " + tableName;
			pst = con.prepareStatement(sql);
			rs = pst.executeQuery();

			//1.��ȡ�������ResultSetMetaData����
			ResultSetMetaData rsmd = rs.getMetaData();
			//2.��ȡ�������¼������
			int colCount = rsmd.getColumnCount();
			
			//3.���ݱ����ҵ�������¼
			DatabaseMetaData meta = con.getMetaData();
			ResultSet primaryKey = meta.getPrimaryKeys(null, null, tableName);//�õ���������
			while(primaryKey.next()){
				if(primaryKey.getString("TABLE_NAME").equals(tableName)){
					break;
				}
			}
			//4.��ӡ��ͷ
			System.out.println("Field\t"+"Type\t"+"Null\t"+"Key\t"+"Extra\t");
			//5.��ӡÿ���ֶε���Ϣ
			for (int i=1; i<=colCount; i++){
				//5.1 �ֶ�����
				String name = rsmd.getColumnLabel(i);
				//5.2 �ֶ�������
				String type = rsmd.getColumnTypeName(i);
				//5.3 �ֶγ���
				int fieldWidth = rsmd.getPrecision(i);
				System.out.print(name+"\t"+type+"("+fieldWidth+")\t");
				
				//5.4 �Ƿ����Ϊ��
				int nullFlag = rsmd.isNullable(i);  
				if(nullFlag==0){
					System.out.print("NO\t");
				}else{
					System.out.print("YES\t");
				}
				
				//5.5 �Ƿ�����
				if(rsmd.getColumnName(i).equals(primaryKey.getString("COLUMN_NAME"))){
					System.out.print("PRI\t");
	            }else {
	            	System.out.print("\t");
	            }
				
				//5.6 �Ƿ�Ϊ�Զ�����
				boolean isIncrement = rsmd.isAutoIncrement(i);
				if(isIncrement){
					System.out.println("auto_increment\t");
				}else {
	            	System.out.println();
	            }
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}finally{
			ResourceUtil.close(rs, pst, con);
		}
	}
}

