package chap3.excercise;

public class Excercise8 {

	/**
	 * ��ӡһ��ѭ�����Ƶı��������
	 */
	public static void main(String[] args) {
		String[] player = new String[]{"1","2","3","4","5"};
		
		//������
		System.out.print("\t");
		for(int i=0; i<player.length; i++){
			System.out.print(player[i]+"\t\t");
		}
		System.out.println();
		
		//�����
		for(int i=0; i<player.length; i++){
			System.out.print(player[i]+"\t");
			for(int j=0; j<player.length; j++){
				if(i!=j){
					System.out.printf("%s~%s\t\t",player[i],player[j]);
				}else{
					System.out.printf("~~~~\t\t",player[i],player[j]);
				}
			}
			System.out.println();
		}
	}

}
