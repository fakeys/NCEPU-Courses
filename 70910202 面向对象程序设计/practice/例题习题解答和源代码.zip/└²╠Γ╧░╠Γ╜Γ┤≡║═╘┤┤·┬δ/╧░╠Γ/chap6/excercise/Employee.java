package chap6.excercise;

public class Employee {
	private String name;

	public Employee(String name) {
		super();
		this.name = name;
	}
	
	public boolean equals(Object obj){
		if (obj instanceof Employee) {
			Employee e = (Employee) obj;
			//return e.name.equals(this.name);
			return e.name==this.name;
		}else{
			return false;
		}
	} 

	
	public static void main(String[] args){
		Employee e1 = new Employee(new String("tom"));
		Employee e2 = new Employee("tom");
		System.out.println(e1==e2);
		System.out.println(e1.equals(e2));
	}
}
