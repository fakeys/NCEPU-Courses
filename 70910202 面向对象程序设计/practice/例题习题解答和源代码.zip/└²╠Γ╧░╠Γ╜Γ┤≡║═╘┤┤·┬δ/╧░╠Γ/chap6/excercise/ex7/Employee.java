package chap6.excercise.ex7;

import java.util.Arrays;

public class Employee implements Comparable {
	
	private String id;
	private String name;
	private double salary;
	
	public Employee() {		
	}
	
	public Employee(String id, String name, double salary) {
		super();
		this.id = id;
		this.name = name;
		this.salary = salary;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSalary() {
		return salary;
	}
	public void setSalary(double salary) {
		this.salary = salary;
	}

	@Override
	public int compareTo(Object obj) {
		if(obj instanceof Employee){
			Employee e = (Employee)obj;
			//return this.name.compareTo(e.name);  //����name��������
			return (int)(this.salary-e.salary);	//���չ�����������
		}
		return 0;
	}
	
	public String toString(){	//��дtoString����
		return id+","+name+","+salary;
	}
	
	
	public static void main(String[] args){
		Employee[] es = new Employee[5];
		es[0]= new Employee("001","zhang",5000);
		es[1]= new Employee("002","li",8000);
		es[2]= new Employee("003","zhao",6000);
		es[3]= new Employee("004","song",6500);
		es[4]= new Employee("005","zhu",9500);
		
		Arrays.sort(es);
		
		for(Employee e: es){
			System.out.println(e);
		}		
	}
	
}
