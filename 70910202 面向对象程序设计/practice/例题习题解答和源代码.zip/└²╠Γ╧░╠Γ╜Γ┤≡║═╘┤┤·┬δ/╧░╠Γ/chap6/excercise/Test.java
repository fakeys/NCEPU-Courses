package chap6.excercise;

class A{
	public void methord(){
		System.out.println("A-method()");
	}
	public void methordA(){
		System.out.println("A-methodA()");
	}
}
class B extends A{
	public void methord(){
		System.out.println("B-method()");
	}
	public void methordB(){
		System.out.println("B-methodB()");
	}
}
public class Test {
	public static void main(String[] args) {
		A a = new B();
		a.methord();
		a.methordA();
		((B)a).methordB();
	}
}
